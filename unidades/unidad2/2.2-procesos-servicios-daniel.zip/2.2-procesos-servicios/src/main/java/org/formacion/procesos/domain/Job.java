package org.formacion.procesos.domain;
/**
 * @author danielrguezh
 * @version 1.0.0
 */
public enum Job {
    LSOF, TOP, PS
}
